Created by Sambouza on GitHub.
Lua Minesweeper CLI

Manual&Controls is in the program itself.
No extra libraries needed! Hence why it is CLI..


To use this program, you'll need to download lua if you don't already have it yourself.
Write in command prompt in the same directory you downloaded minesweeper. e.g. You downloaded minesweeper in C:\Minesweeper. So set that as your directory using 'cd C:\Minesweeper' in command prompt! To run it, whilst the current directory is set,  type '(lua54.exe path location, e.g. C:\Program Files\Lua\lua54) Minesweeper.lua'. And then it should run!

I probably did a terrible job on explaining that so just search a video on how to install lua and run files.

Apologies in advance for my spagheitti code
This is my first program/game created in lua so expect alot of bugs.
Feel free to copy the game (but please don't claim it as your own unless you heavily modified it. That wouldn't be nice >:( )